<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
          /* background: url(img.jpg) no-repeat;*/
          background : black;
     margin: 0;
	padding: 0;
	font-family: sans-serif;
	background: url(img.jpg) no-repeat;
	background-size: cover;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .loginbox {
               float: left;
	font-size: 40px;
	border-bottom: 6px solid #4caf50;
	margin-bottom: 50px;
	padding: 13px
            }
            .formbox{
                width: 280px;
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%,-50%);
	color: white;
            }
            .textbox{
                width: 100%;
	overflow: hidden;
	font-size: 20px;
	padding: 8px 0;
	margin: 8px 0;
	border-bottom: 1px solid #4caf50;
            }
            .textbox input{
                border: none;
	outline: none;
	background: none;
	color: white;
	font-size: 18px;
	width: 80%;
	float: left;
	margin: 0 10px;
            }
            .button {
                width: 100%;
	background: none;
	border: 2px solid #4caf50;
	color: white;
	padding: 5px;
	font-size: 18px;
	cursor: pointer;
	margin: 12px 0;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @else
                        <a href="{{ route('login') }}">Login</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}">Register</a>
                        @endif
                    @endauth
                </div>
            @endif

            <div class="content">
                <div class="loginbox">
                    LOGIN
                </div>
               
                <form class"formbox" action="{{URL::to('/logs')}}" method="post" >
                @csrf
                
             
                <div class="textbox">
                <input type="text" name="username" placeholder="Enter Your UserName" value="">
                </div>
                
                <div class="textbox">
                <input type="password" name="password" placeholder="Enter Your password" value="">
                </div>
                
                
                <div class="textbox">
                <input type="hidden" name="_token" value="{{csrf_token()}}">
                </div>
                <div class="button">
                <button type="submit" name="button"><a href="{{URL::to('/welcome')}}">Login</a></button>
                </div>
                </form>
                
            </div>
        </div>
        @if($errors->any())
        <div>
          <ul>
              @foreach($errors->all() as $error)
              <li>{{$error}}</li>
              @endforeach
          </ul
        </div>
        @endif

    </body>
</html>
