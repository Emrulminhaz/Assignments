<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="style.css">
        <!-- Styles -->
        <style>
            html, body {
                	margin: 0;
	padding: 0;
	font-family: sans-serif;
	background: url(img.jpg) no-repeat;
	background-size: cover;
            }

           

            .button{
	text-align: right;
	width: 100%;
}
.button a{
	color:white;
	text-decoration: none;
}
.btn1,.btn2{
	
	padding-left: 40px;
	background: none;
	border: 2px solid #4caf50;
	color: white;
	padding: 5px;
	font-size: 18px;
	cursor: pointer;
	margin: 12px 0;

}

.wel{
	text-align: center;
	width: 100%;
	top: 250px;
	color: white;
	position: absolute;
	font-size: 30px;
	letter-spacing: 5px;
}

        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @else
                        <a href="{{ route('login') }}">Login</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}">Register</a>
                        @endif
                    @endauth
                </div>
            @endif

            <div class="content">
                <div class="title m-b-md">
                  
                </div>

               	<div  class="button">
		<button class="btn2"><a href="{{URL::to('/login')}}">Login</a></button>
	    <button class="btn1"><a href="{{URL::to('/register')}}">Register</a></button> 

	</div>

	<div class="wel">

    	<h1>WELCOME   TO   THIS    PAGE</h1>

    </div>
            </div>
        </div>
    </body>
</html>
