<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="style.css">
        <!-- Styles -->
        <style>
            html, body {
                	margin: 0;
	padding: 0;
	font-family: sans-serif;
	background: url(img.jpg) no-repeat;
	background-size: cover;
            }

           

            .button{
	text-align: right;
	width: 100%;
}
.button a{
	color:white;
	text-decoration: none;
}
.btn1,.btn2{
	
	padding-left: 40px;
	background: none;
	border: 2px solid #4caf50;
	color: white;
	padding: 5px;
	font-size: 18px;
	cursor: pointer;
	margin: 12px 0;

}

.wel{
	text-align: center;
	width: 100%;
	top: 250px;
	color: white;
	position: absolute;
	font-size: 30px;
	letter-spacing: 5px;
}

        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">
                  
                </div>

               	<div  class="button">
		<button class="btn2"><a href="<?php echo e(URL::to('/login')); ?>">Login</a></button>
	    <button class="btn1"><a href="<?php echo e(URL::to('/register')); ?>">Register</a></button> 

	</div>

	<div class="wel">

    	<h1>WELCOME   TO   THIS    PAGE</h1>

    </div>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp1\htdocs\dashboard\Emrul\laravel\laravel\resources\views/welcome.blade.php ENDPATH**/ ?>