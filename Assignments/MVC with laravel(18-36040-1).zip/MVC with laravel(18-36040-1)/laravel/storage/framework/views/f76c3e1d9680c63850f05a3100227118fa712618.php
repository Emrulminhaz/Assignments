<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
      

     	<link rel="stylesheet" type="text/css" href="style.blade.css">
     
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">
                    Laravel
                </div>

                <div  class="button">
		<button class="btn2"><a href="login.blade.php">Login</a></button>
	    <button class="btn1"><a href="Registration.blade.php">Register</a></button> 

	</div>

	<div class="wel">

    	<h2>WELCOME   TO   THIS    PAGE</h2>

    </div>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp1\htdocs\dashboard\Emrul\laravel\laravel\resources\views/wel.blade.php ENDPATH**/ ?>