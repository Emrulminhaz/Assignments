<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\DB;
class UserController extends Controller
{
    public function store(request $request)
    {
    
    $firstname=$request->input('firstname');
        $lastname=$request->input('lastname');
        $username=$request->input('username');
        $email=$request->input('email');
        $password=$request->input('password');
        if($firstname != "" && $lastname != "" && $username != "" && $email != "" && $password != ""){
            echo DB::insert('insert into users(firstname,lastname,username,email,password) values(?,?,?,?,?)',[$firstname,$lastname,$username,$email,$password]);
        }
         
}

  public function logs(request $request)
    {   print_r($request->input());
   //return false;
        $username=$request->input('username');
        $password=$request->input('password');
       $data = DB::select('select id from users where username=? and password=?',[$username,$password]);
       print_r($data);
}


}





