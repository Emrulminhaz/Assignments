<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ValidationController extends Controller
{
    public function show(request $request)
    {
      $validation $request -> validate([
         'firstname' => 'required | min:3 | max:20',
         'lastname' => 'required | min:3 | max:20',
         'username' => 'required | min:3 | max:20',
         'email' => 'required | min:3 | max:20',
         'password' => 'required | min:8 | numaric'


      ]);

      print_r($validation);
    }
}
