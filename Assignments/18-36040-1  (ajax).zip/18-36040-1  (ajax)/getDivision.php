<?php
$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "Divisionofcity";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	$sql = "SELECT * FROM division WHERE divisionname='". $_GET['q']."'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) { 
		while($row = $result->fetch_assoc()){
		 echo $row["id"];
		 echo ". <a href='".$row["link"]."'>".$row["city"]."</a>";
		 echo "<br>" ; 
		}
	}

?>