-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2020 at 03:00 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `divisionofcity`
--

-- --------------------------------------------------------

--
-- Table structure for table `division`
--

CREATE TABLE `division` (
  `id` int(6) UNSIGNED NOT NULL,
  `divisionname` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `link` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `division`
--

INSERT INTO `division` (`id`, `divisionname`, `city`, `link`) VALUES
(1, 'Dhaka', 'Dhaka', 'https://en.wikipedia.org/wiki/Dhaka_District'),
(2, 'Dhaka', 'Faridpur', 'https://en.wikipedia.org/wiki/Faridpur_District'),
(3, 'Dhaka', 'Gazipur', 'https://en.wikipedia.org/wiki/Gazipur_District'),
(4, 'Dhaka', 'Gopalganj', 'https://en.wikipedia.org/wiki/Gopalganj_District,_Bangladesh'),
(5, 'Dhaka', 'Madaripur', 'https://en.wikipedia.org/wiki/Madaripur_District'),
(6, 'Dhaka', 'Tangail', 'https://en.wikipedia.org/wiki/Tangail_District'),
(7, 'Dhaka', 'Manikganj', 'https://en.wikipedia.org/wiki/Manikganj_District'),
(8, 'Dhaka', 'Munshiganj', 'https://en.wikipedia.org/wiki/Munshiganj_District'),
(9, 'Dhaka', 'Narayanganj', 'https://en.wikipedia.org/wiki/Narayanganj_District'),
(10, 'Dhaka', 'Kishoreganj', 'https://en.wikipedia.org/wiki/Kishoreganj_District'),
(11, 'Dhaka', 'Narsingdhi', 'https://en.wikipedia.org/wiki/Narsingdi_District'),
(12, 'Dhaka', 'Rajbari', 'https://en.wikipedia.org/wiki/Rajbari_District'),
(13, 'Dhaka', 'Shariatpur', 'https://en.wikipedia.org/wiki/Shariatpur_District'),
(14, 'Chattogram', 'Chattogram', 'https://en.wikipedia.org/wiki/Chittagong_District'),
(15, 'Chattogram', 'Bandarban', 'https://en.wikipedia.org/wiki/Bandarban_District'),
(16, 'Chattogram', 'Brahmanbaria', 'https://en.wikipedia.org/wiki/Brahmanbaria_District'),
(17, 'Chattogram', 'Chandpur', 'https://en.wikipedia.org/wiki/Chandpur_District'),
(18, 'Chattogram', 'Cumilla', 'https://en.wikipedia.org/wiki/Comilla_District'),
(19, 'Chattogram', 'Cox\'s Bazar', 'https://en.wikipedia.org/wiki/Cox%27s_Bazar_District'),
(20, 'Chattogram', 'Feni', 'https://en.wikipedia.org/wiki/Feni_District'),
(21, 'Chattogram', 'Khagrachhari', 'https://en.wikipedia.org/wiki/Khagrachhari_District'),
(22, 'Chattogram', 'Lakshmipur', 'https://en.wikipedia.org/wiki/Lakshmipur_District'),
(23, 'Chattogram', 'Noakhali', 'https://en.wikipedia.org/wiki/Noakhali_District'),
(24, 'Chattogram', 'Rangamati', 'https://en.wikipedia.org/wiki/Rangamati_Hill_District'),
(25, 'Barisal', 'Barishal', 'https://en.wikipedia.org/wiki/Barisal_District'),
(26, 'Barisal', 'Barguna', 'https://en.wikipedia.org/wiki/Barguna_District'),
(27, 'Barisal', 'Bhola', 'https://en.wikipedia.org/wiki/Bhola_District'),
(28, 'Barisal', 'Jhalokati', 'https://en.wikipedia.org/wiki/Jhalokati_District'),
(29, 'Barisal', 'Pirojpur', 'https://en.wikipedia.org/wiki/Pirojpur_District'),
(30, 'Khulna', 'Khulna', 'https://en.wikipedia.org/wiki/Khulna_District'),
(31, 'Khulna', 'Bagerhat', 'https://en.wikipedia.org/wiki/Bagerhat_District'),
(32, 'Khulna', 'Chuadanga', 'https://en.wikipedia.org/wiki/Chuadanga_District'),
(33, 'Khulna', 'Jashore', 'https://en.wikipedia.org/wiki/Jessore_District'),
(34, 'Khulna', 'Jhenaidah', 'https://en.wikipedia.org/wiki/Jhenaidah_District'),
(35, 'Khulna', 'Kushtia', 'https://en.wikipedia.org/wiki/Kushtia_District'),
(36, 'Khulna', 'Magura', 'https://en.wikipedia.org/wiki/Magura_District'),
(37, 'Khulna', 'Meherpur', 'https://en.wikipedia.org/wiki/Meherpur_District'),
(38, 'Khulna', 'Narail', 'https://en.wikipedia.org/wiki/Narail_District'),
(39, 'Khulna', 'Satkhira', 'https://en.wikipedia.org/wiki/Satkhira_District'),
(40, 'Mymensingh', 'Mymensingh', 'https://en.wikipedia.org/wiki/Mymensingh_District'),
(41, 'Mymensingh', 'Jamalpur', 'https://en.wikipedia.org/wiki/Jamalpur_District'),
(42, 'Mymensingh', 'Netrokona', 'https://en.wikipedia.org/wiki/Netrokona_District'),
(43, 'Mymensingh', 'Sherpur', 'https://en.wikipedia.org/wiki/Sherpur_District'),
(44, 'Rajshahi', 'Rajshahi', 'https://en.wikipedia.org/wiki/Rajshahi_District'),
(45, 'Rajshahi', 'Bogura', 'https://en.wikipedia.org/wiki/Bogra_District'),
(46, 'Rajshahi', 'Joypurhat', 'https://en.wikipedia.org/wiki/Joypurhat_District'),
(47, 'Rajshahi', 'Naogaon', 'https://en.wikipedia.org/wiki/Naogaon_District'),
(48, 'Rajshahi', 'Natore', 'https://en.wikipedia.org/wiki/Natore_District'),
(49, 'Rajshahi', 'Chapainawabhanj', 'https://en.wikipedia.org/wiki/Chapai_Nawabganj_District'),
(50, 'Rajshahi', 'Pabna', 'https://en.wikipedia.org/wiki/Pabna_District'),
(51, 'Rajshahi', 'Sirajganj', 'https://en.wikipedia.org/wiki/Sirajganj_District'),
(52, 'Rangpur', 'Rangpur', 'https://en.wikipedia.org/wiki/Rangpur_District'),
(53, 'Rangpur', 'Dinajpur', 'https://en.wikipedia.org/wiki/Dinajpur_District,_Bangladesh'),
(54, 'Rangpur', 'Gaibandha', 'https://en.wikipedia.org/wiki/Gaibandha_District'),
(55, 'Rangpur', 'kurigram', 'https://en.wikipedia.org/wiki/Kurigram_District'),
(56, 'Rangpur', 'Lalmonirhat', 'https://en.wikipedia.org/wiki/Lalmonirhat_District'),
(58, 'Rangpur', 'Nilphamari', 'https://en.wikipedia.org/wiki/Nilphamari_District'),
(59, 'Rangpur', 'Panchagarh', 'https://en.wikipedia.org/wiki/Panchagarh_District'),
(60, 'Rangpur', 'Thakurgaon', 'https://en.wikipedia.org/wiki/Thakurgaon_District'),
(61, 'Sylhet', 'Sylhet', 'https://en.wikipedia.org/wiki/Sylhet_District'),
(62, 'Sylhet', 'Habiganj', 'https://en.wikipedia.org/wiki/Habiganj_District'),
(63, 'Sylhet', 'Moulvibazar', 'https://en.wikipedia.org/wiki/Moulvibazar_District'),
(64, 'Sylhet', 'Sunamganj', 'https://en.wikipedia.org/wiki/Sunamganj_District'),
(65, 'Barisal', 'Patuakhali', 'https://en.wikipedia.org/wiki/Patuakhali_District');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `division`
--
ALTER TABLE `division`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `division`
--
ALTER TABLE `division`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
